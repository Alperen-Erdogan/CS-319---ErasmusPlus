import React from 'react'

const Header = () => {
  return (
    <header>
        <h1>Header test</h1>
    </header>
  )
}

export default Header